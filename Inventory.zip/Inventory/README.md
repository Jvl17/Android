Inventory app
==================================

Solution code for Android Basics with Compose.

Getting Started
---------------

1. Download and run the app.
